[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/RsX5aflH)
# Kaggle House Prediction Presentation

These are starter ioslides.  You should use five-fifteen slides (not including the cover slide).  All code, data, etc should be in the slides and reproducible.  Your talk is to be no more than 7 minutes long. Please practice your presentation so that it is polished!  
